export type MenuItem = {
  label: string;
  link: string;
};